import React from 'react';

import 'bootstrap/dist/css/bootstrap.css';

function Navbar() {
  return (
  <>
  	
<nav className="navbar navbar-expand-sm bg-dark navbar-dark fixed-top d-flex justify-content-between">
  <a className="navbar-brand" href="/">PARKING SLOT BOOKING SYSTEM</a>
  <a className='text-end' href="https://github.com/aryaVeerJai">By Jai Prakash Kumar</a>
 
</nav>
  	
  	
  	</>
  );
}

export default Navbar;
