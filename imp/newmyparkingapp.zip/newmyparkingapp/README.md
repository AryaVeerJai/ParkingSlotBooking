1) Clone this repository
2) Just move to the directory                                 -->  cd parking-slot
3)run command  for setting up new npm package                 --> npm init
4)Install dependencies for the project                        -->npm install
5)Run the application with command                            -->npm start
6)Accessing it in browser                                      http://localhost:3000
7)To access this live just access the link:
https://parking-slot-management-system.herokuapp.com/
